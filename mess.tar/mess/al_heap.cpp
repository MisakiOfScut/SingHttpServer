#include <iterator>
#include <vector>
#include <iostream>
using namespace std;

template<typename RandomAccessIterator>
void push_heap(RandomAccessIterator first, RandomAccessIterator last){
    using value_type = typename iterator_traits<RandomAccessIterator>::value_type;
    using diff_type = typename iterator_traits<RandomAccessIterator>::difference_type;

    if((last-1) <= first)// size <= 1
        return;

    value_type new_add_val = *(last-1);
    diff_type child = last-first-1;
    diff_type parent = (child-1)/2;

    //当子节点的值大于父节点
    while(child>0 && *(first+parent) < new_add_val){
        *(first + child) = *(first + parent); //将父节点的值设置到子节点
        child = parent; //上溯
        parent = (child-1)/2;
    }

    *(first+child) = new_add_val; //最后将新加入的值放到它应处于的位置
}

//pop_heap是一个下溯的过程，将大的子节点的值上移，然后parent设置为子节点，重复这个过程直到parent已经是叶节点
//将堆顶first放到last-1，并且调整[first,last-2]
template <typename RandomAccessIterator>
void pop_heap(RandomAccessIterator first, RandomAccessIterator last){
    using value_type = typename iterator_traits<RandomAccessIterator>::value_type;
    using diff_type = typename iterator_traits<RandomAccessIterator>::difference_type;
    
    value_type pop_val = *first;
    diff_type parent = 0, left = 1, right = 2;
    diff_type len = last-first;

    while(right<len){
        if(*(first+left) > *(first+right)){
           *(first+parent) = *(first+left);
           parent = left;
        }else{
            *(first+parent) = *(first+right);
            parent = right;
        }
        left = 2*parent + 1;
        right = left + 1;
    }

    if(right==len){// last sub-tree no right child
        *(first+parent) = *(first+left);
        parent = left;
    }

    //此时parent位置空缺，由于要将pop_val放到最后，所以把最后位置的值放到这里 
    *(first+parent) = *(last-1);
    
    //将上面放过来的值上溯找到它正确的位置
    push_heap(first, first+parent+1); 

    //将要堆顶值放到最后
    *(last-1) = pop_val;
}

template<typename RandomAccessIterator>
void make_heap(RandomAccessIterator first, RandomAccessIterator last){
    if(last-first <= 1) return;

    for(auto it = first+2;it != last;++it){
        push_heap(first,it);
    }
}

template<typename RandomAccessIterator>
void heap_sort(RandomAccessIterator first, RandomAccessIterator last){
    if(last-first<=1) return;

    //i=first+2时，排序最前面两个元素
    for(auto i=last;i>=first+2;--i){
        pop_heap(first,i);
    }
}

int main(){
    vector<int> arr = {50,21,31,32,19,26,13,24,68,65,16}; 
    make_heap(arr.begin(), arr.end());
    heap_sort(arr.begin(), arr.end());
    //{68,50,65,21,31,32,26,19,16,13,24};
    //pop_heap(arr.begin(), arr.end());
    //push_heap(arr.begin(), arr.end());
    for(auto a:arr){
        cout<<a<<" ";
    } 
    return 0;

}


