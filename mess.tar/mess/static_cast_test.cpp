#include <iostream>
using namespace std;

class Base{
public:
    virtual void onResize(){
        a = 1;
    }
    int a = 0;
};

class Der:public Base{
public:
    virtual void Resize(){
        static_cast<Base*>(this)->onResize();
        a += 1;
    }
    
};

int main(){
    Der d;
    d.Resize();
    cout<<d.a<<endl;
    return 0;
}
