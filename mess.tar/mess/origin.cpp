#include<iostream>
#include <memory>
using namespace std;
union __end
{
	int a;
	char b;
};

int main(){
	__end e;
	e.a = 1;
	if (e.b){
		cout <<"small end"<< endl;
	}else{
		cout<<"big end" << endl;
	}
	
	return 0;
}
