#include <stddef.h>
#include <iostream>

using namespace std;
int b;
static int c; 

class E{
public:
    int e;
};

int main(){
    int a;
    static int d;
    E e;
    cout<<a<<"\t"<<b<<endl;        
    cout<<c<<"\t"<<d<<endl;  
    cout<<e.e;
}
